// HAL_SDCard.h

#ifndef _HAL_SDCard_h
#define _HAL_SDCard_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif
//
//#include <SPI.h>
//#include "SD.h"
#include "TelemetryLogging.h"

	void SD_Logging_Init();
	void SD_Logging_OpenFile(word LoggingMask);
	void SD_Logging(word LoggingMask);

	void OpenSDLogFile(String LogFileName);

	void Check_LogFileSize(word LoggingMask);
	void CloseThenOpenLogFile(word LoggingMask);
	void Check_GPS_TimeStatus(word LoggingMask);

	void SD_Logging_Event_Decisions(word LoggingMask);
	void SD_Logging_Event_Usage(word LoggingMask);
	void SD_Logging_Event_ParameterChange(int ParameterIndex, char ParameterValue[12]);
	void SD_Logging_Event_Messsage(String message);
	void SD_Logging_Event_MissionStep(int mission_index);

#endif

